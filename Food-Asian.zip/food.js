
var icon = document.querySelector('#icon');
var allmenu = document.querySelector('#allmenu');
icon.onclick = () =>{
    icon.classList.toggle('fa-times')
    allmenu.classList.toggle('active');
}
window.onscroll = () =>{
    icon.classList.remove('fa-times')
    allmenu.classList.remove('active');
}
document.querySelector('#search').onclick = () =>{
    document.querySelector('#search-form').classList.toggle('active');
}
document.querySelector('#close').onclick = () =>{
    document.querySelector('#search-form').classList.remove('active');
}
var swiper = new Swiper(".home-slider", {
    spaceBetween: 30,
    centeredSlides: true,
    autoplay: {
      delay: 2200,
      disableOnInteraction: false,
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    loop:true,
  });

    
 